#!/bin/sh
properties() { '
kernel.string=GT7 Pro 6.6.118 SukiSU Ultra + SUSFS for RMX5010_16.0.10.500(CN01)
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=0
device.name1=RE6018L1
device.name2=RMX5010
supported.versions=16
supported.patchlevels=2026-08-01 - 2026-08-01
'; }
BLOCK=boot;
IS_SLOT_DEVICE=1;
RAMDISK_COMPRESSION=auto;
PATCH_VBMETA_FLAG=0;
. tools/ak3-core.sh;
expected_fingerprint='realme/RMX5010/RE6018L1:16/BP2A.250605.015/V.2a20db9-4ff7c3-520e61:user/release-keys';
actual_fingerprint=$(getprop ro.build.fingerprint);
[ "$actual_fingerprint" = "$expected_fingerprint" ] || abort "System version mismatch: this package is only for RMX5010_16.0.10.500(CN01).";
case "$(uname -r)" in
  6.6.118-*) ;;
  *) abort "Kernel generation mismatch: expected 6.6.118." ;;
esac;
ui_print "Replacing only the current slot boot kernel.";
split_boot;
flash_boot;
