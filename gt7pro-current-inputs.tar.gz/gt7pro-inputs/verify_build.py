import sys, pathlib, re, json, hashlib, struct, gzip
root=pathlib.Path(sys.argv[1]); inputs=pathlib.Path(sys.argv[2]); out=root/'out'
errors=[]; report={}
config=(out/'.config').read_text(); cfg=dict(re.findall(r'^(CONFIG_\w+)=(.*)$',config,re.M))
critical={'CONFIG_KSU':'y','CONFIG_KSU_SUSFS':'y','CONFIG_ARM64_4K_PAGES':'y','CONFIG_MODVERSIONS':'y','CONFIG_CFI_CLANG':'y','CONFIG_PREEMPT':'y','CONFIG_MODULES':'y'}
for n,v in critical.items():
 if cfg.get(n)!=v:errors.append(f'{n}: expected {v}, found {cfg.get(n)}')
if cfg.get('CONFIG_KPM')=='y':errors.append('Unexpected KPM enabled')
required=json.loads((inputs/'required-kernel-crcs.json').read_text()); actual={}
for line in (out/'Module.symvers').read_text().splitlines():
 parts=line.split()
 if len(parts)>=3 and parts[2]=='vmlinux':actual[parts[1]]=parts[0]
missing=sorted(set(required)-set(actual))
mismatch=[{'symbol':n,'required':v,'actual':actual[n]} for n,v in required.items() if n in actual and int(v,16)!=int(actual[n],16)]
if missing:errors.append(f'{len(missing)} required kernel symbols missing')
if mismatch:errors.append(f'{len(mismatch)} kernel symbol CRC mismatches')
image=(out/'arch/arm64/boot/Image').read_bytes()
if image[56:60]!=b'ARM\x64':errors.append('Invalid ARM64 Image magic')
flags=struct.unpack_from('<Q',image,24)[0]
if (flags>>1)&3!=1:errors.append('Image page size is not 4K')
banners=re.findall(rb'Linux version [^\x00\n]{1,500}',image)
if not banners or not banners[0].startswith(b'Linux version 6.6.118-'):errors.append('Unexpected real kernel version')
start=image.find(b'IKCFG_ST'); end=image.find(b'IKCFG_ED',start)
if start<0 or end<0:errors.append('Embedded config missing')
else:
 embedded=gzip.decompress(image[start+8:end]).decode()
 ecfg=dict(re.findall(r'^(CONFIG_\w+)=(.*)$',embedded,re.M))
 if any(ecfg.get(n)!=v for n,v in critical.items()):errors.append('Embedded config does not have requested features')
 if ecfg!=cfg:errors.append('Embedded config differs from build config')
if not (out/'fs/susfs.o').is_file():errors.append('SUSFS object missing')
if not (out/'drivers/kernelsu/ksu.o').is_file():errors.append('SukiSU object missing')
report.update(critical_config={n:cfg.get(n) for n in critical},required_kernel_symbols=len(required),matching_kernel_symbols=len(required)-len(missing)-len(mismatch),missing=missing,mismatches=mismatch,banners=[b.decode(errors='replace') for b in banners],image_size=len(image),image_sha256=hashlib.sha256(image).hexdigest(),page_size='4K',errors=errors,passed=not errors)
(out/'compatibility-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
sys.exit(bool(errors))
